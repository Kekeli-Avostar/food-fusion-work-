<?php
header("Content-Type: application/json");

require_once "../config/db.php";

try {
  $stmt = $conn->prepare("SELECT * FROM resources ORDER BY uploaded_at DESC");
  $stmt->execute();
  $resources = [];

  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $resources[] = $row;
  }

  echo json_encode($resources, JSON_UNESCAPED_UNICODE);
} catch (PDOException $e) {
  http_response_code(500);
  echo json_encode(["error" => "Database error"]);
  error_log($e->getMessage());
}
?>

document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("recipeForm");
    const postsContainer = document.getElementById("posts-container");
    const statusMessage = document.getElementById("statusMessage");

    // Handle form submission
    form.addEventListener("submit", function (e) {
        e.preventDefault();

        // Get input values
        const title = document.getElementById("recipeTitle").value.trim();
        const description = document.getElementById("recipeDescription").value.trim();
        const instructions = document.getElementById("instructions").value.trim();

        // Check for required fields
        if (!title || !description || !instructions) {
            statusMessage.style.color = 'red';
            statusMessage.textContent = "Please fill out all required fields.";
            return;
        }

        // Simulate submission process
        statusMessage.style.color = '#333';
        statusMessage.textContent = "Submitting...";

        setTimeout(() => {
            // Create new post element
            const post = document.createElement("div");
            post.classList.add("post");

            post.innerHTML = `
                <h3>${title}</h3>
                <p>${description}</p>
                <p><strong>Ingredients:</strong><ul id="ingredients-list"></ul></p>
                <p><strong>Instructions:</strong><br/>${instructions}</p>
                <div class="likes-comments">
                    <button class="like-btn">❤️ Like (<span class="like-count">0</span>)</button>
                    <button class="comment-btn">💬 Comment</button>
                </div>
            `;

            // Dynamically add ingredients
            const ingredientsList = document.getElementById('ingredients-list');
            const ingredients = document.querySelectorAll('[name="ingredients[]"]');
            ingredients.forEach(ingredient => {
                const listItem = document.createElement('li');
                listItem.textContent = ingredient.value;
                ingredientsList.appendChild(listItem);
            });

            // Add post to the top of the posts container
            postsContainer.prepend(post);

            // Clear form fields
            form.reset();

            // Add like button functionality
            const likeBtn = post.querySelector(".like-btn");
            const likeCount = post.querySelector(".like-count");

            likeBtn.addEventListener("click", function () {
                let count = parseInt(likeCount.innerText);
                count++;
                likeCount.innerText = count;
            });

            // Add comment button functionality (for now, it just logs a message)
            const commentBtn = post.querySelector(".comment-btn");
            commentBtn.addEventListener("click", function () {
                console.log("Comment button clicked for", title);
            });

            // Show success message
            statusMessage.style.color = 'green';
            statusMessage.textContent = "Recipe submitted successfully! 🍽️";
        }, 2000); // Fake delay to simulate backend interaction
    });

    // Dynamically add ingredient fields
    const addIngredientBtn = document.querySelector('button[type="button"]');
    addIngredientBtn.addEventListener("click", function () {
        const ingredientDiv = document.getElementById("ingredients");
        const newInput = document.createElement('input');
        newInput.type = 'text';
        newInput.name = 'ingredients[]';
        newInput.placeholder = 'Ingredient';
        newInput.required = true;
        ingredientDiv.appendChild(newInput);
    });
});

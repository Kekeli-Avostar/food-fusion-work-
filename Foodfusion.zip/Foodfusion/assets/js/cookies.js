// cookies.js
document.addEventListener("DOMContentLoaded", () => {
    const headers = document.querySelectorAll(".accordion-header");
    const searchInput = document.getElementById("policy-search");
  
    // Toggle accordion
    headers.forEach(h => {
      h.addEventListener("click", () => {
        h.classList.toggle("active");
        const body = h.nextElementSibling;
        if (h.classList.contains("active")) {
          body.style.maxHeight = body.scrollHeight + "px";
        } else {
          body.style.maxHeight = null;
        }
      });
    });
  
    // Live search/filter
    searchInput.addEventListener("input", () => {
      const term = searchInput.value.toLowerCase();
      document.querySelectorAll(".accordion-item").forEach(item => {
        const text = item.textContent.toLowerCase();
        item.style.display = text.includes(term) ? "" : "none";
      });
    });
  });
  
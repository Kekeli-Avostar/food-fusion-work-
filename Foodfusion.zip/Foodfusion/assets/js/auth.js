document.addEventListener("DOMContentLoaded", () => {
    // Show/hide password
    document.querySelectorAll(".toggle-password").forEach(toggle => {
      const input = document.querySelector(`#${toggle.dataset.toggle}`);
      toggle.addEventListener("click", () => {
        const type = input.getAttribute("type") === "password" ? "text" : "password";
        input.setAttribute("type", type);
        toggle.textContent = type === "password" ? "👁️" : "🙈";
      });
    });
  
    // Simple client-side validation feedback
    document.querySelectorAll(".auth-form").forEach(form => {
      form.addEventListener("submit", e => {
        let valid = true;
        form.querySelectorAll("input[required]").forEach(input => {
          if (!input.value.trim()) {
            valid = false;
            input.style.borderColor = "#e74c3c";
          } else {
            input.style.borderColor = "#ccc";
          }
        });
        if (!valid) {
          e.preventDefault();
        }
      });
    });
  });
  
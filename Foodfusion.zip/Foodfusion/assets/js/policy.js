document.addEventListener("DOMContentLoaded", () => {
    const headers = document.querySelectorAll(".accordion-header");
    const searchInput = document.getElementById("policy-search");
  
    // Accordion toggle
    headers.forEach(header => {
      header.addEventListener("click", () => {
        header.classList.toggle("active");
        const body = header.nextElementSibling;
        if (header.classList.contains("active")) {
          body.style.maxHeight = body.scrollHeight + "px";
        } else {
          body.style.maxHeight = null;
        }
      });
    });
  
    // Live search/filter
    searchInput.addEventListener("input", () => {
      const term = searchInput.value.toLowerCase();
      document.querySelectorAll(".accordion-item").forEach(item => {
        const text = item.textContent.toLowerCase();
        item.style.display = text.includes(term) ? "" : "none";
      });
    });
  });
  
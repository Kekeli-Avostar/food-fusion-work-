// recipes_toggle.js
document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".recipe-card").forEach(card => {
      card.addEventListener("click", () => {
        const id = card.dataset.id;
        const ing = document.getElementById(`ings-${id}`);
        ing.classList.toggle("open");
      });
    });
  });
  
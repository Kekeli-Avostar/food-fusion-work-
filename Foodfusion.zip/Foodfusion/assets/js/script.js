// Cookie modal logic
document.addEventListener("DOMContentLoaded", () => {
    const modal = document.getElementById("cookie-modal");
    const acceptBtn = document.getElementById("accept-cookies");
    const declineBtn = document.getElementById("decline-cookies");
  
    if (!localStorage.getItem("cookiesDecision")) {
      modal.style.display = "flex";
    }
  
    acceptBtn.addEventListener("click", () => {
      localStorage.setItem("cookiesDecision", "accepted");
      modal.style.display = "none";
    });
  
    declineBtn.addEventListener("click", () => {
      localStorage.setItem("cookiesDecision", "declined");
      modal.style.display = "none";
    });
  });
  
  // Signup modal functions (existing)
  function openSignup() {
    document.getElementById("signup-modal").style.display = "flex";
  }
  function closeSignup() {
    document.getElementById("signup-modal").style.display = "none";
  }
  // Form validation (existing)
  function validateForm() {
    // ...
    return true;
  }
  
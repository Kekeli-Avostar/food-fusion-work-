document.addEventListener("DOMContentLoaded", () => {
    const banner = document.getElementById("cookie-banner");
    const acceptBtn = document.getElementById("accept-cookies");
  
    // If already accepted, hide banner
    if (localStorage.getItem("cookiesAccepted") === "true") {
      banner.style.display = "none";
    }
  
    acceptBtn.addEventListener("click", () => {
      localStorage.setItem("cookiesAccepted", "true");
      banner.style.display = "none";
    });
  });
  
document.getElementById("contactForm").addEventListener("submit", function (event) {
    event.preventDefault();

    let formData = new FormData(this);
    let statusMessage = document.getElementById("statusMessage");

    statusMessage.style.color = "#333";
    statusMessage.textContent = "Sending message... ⏳";

    fetch("../actions/contact_submit.php", {
        method: "POST",
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        statusMessage.textContent = data.message;
        statusMessage.style.color = data.status === "success" ? "green" : "red";
        if (data.status === "success") {
            this.reset();
        }
    })
    .catch(() => {
        statusMessage.textContent = "Error sending message. Try again later.";
        statusMessage.style.color = "red";
    });
});

<nav>
    <div class="logo">FoodFusion</div>
    <ul>
        <li><a href="../pages/home.php">Home</a></li>
        <li><a href="../pages/about.php">About Us</a></li>
        <li><a href="../pages/recipes.php">Recipes</a></li>
        <li><a href="../pages/community.php">Community</a></li>
        <li><a href="../pages/culinary.php">Culinary Resources</a></li>
        <li><a href="../pages/education.php">Educational Resources</a></li>
        <li><a href="../pages/contact.php">Contact Us</a></li>
    </ul>
</nav>

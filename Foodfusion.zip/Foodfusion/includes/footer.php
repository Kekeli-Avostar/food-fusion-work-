<footer>
    <p>&copy; <?php echo date("Y"); ?> FoodFusion. All rights reserved.</p>
    <div class="socials">
        <a href="https://www.facebook.com/FoodFusionPK" target="_blank">Facebook</a> | 
        <a href="https://twitter.com">Twitter</a> | 
        <a href="https://www.instagram.com/foodfusionpk/?fbclid=IwY2xjawJqCAFleHRuA2FlbQIxMAABHq87wwierc9b-Lg-X1p_2bxDiot83YpMRiwFELbTlbefgcvQyIL3EloPiLya_aem_N97_cPVUvFsCDqqgpsVtWg#" target="_blank">Instagram</a>
    <nav class="footer-links">
      <a href="privacy-policy.php">Privacy Policy</a> |
      <a href="cookie-policy.php">Cookie Policy</a>
    </div>


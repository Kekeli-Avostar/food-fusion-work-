<?php include "../includes/navbar.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Privacy Policy | FoodFusion</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="../assets/css/policy.css">
  <script src="../assets/js/policy.js" defer></script>
</head>
<body>

<header class="policy-hero">
  <h1>Privacy Policy</h1>
  <p>Your privacy matters—find exactly what you’re looking for below.</p>
</header>

<main class="policy-container">
  <div class="policy-search">
    <input type="text" id="policy-search" placeholder="Search policy…">
  </div>

  <div class="accordion" id="policy-accordion">
    <div class="accordion-item">
      <button class="accordion-header">1. Introduction</button>
      <div class="accordion-body">
        <p>Welcome to FoodFusion. We respect your privacy and are committed to protecting your personal data.</p>
      </div>
    </div>

    <div class="accordion-item">
      <button class="accordion-header">2. Data We Collect</button>
      <div class="accordion-body">
        <ul>
          <li>Information you provide when registering or contacting us.</li>
          <li>Usage data: pages visited, time spent, etc.</li>
          <li>Cookies and tracking technologies.</li>
        </ul>
      </div>
    </div>

    <div class="accordion-item">
      <button class="accordion-header">3. How We Use Your Data</button>
      <div class="accordion-body">
        <p>We use your data to:</p>
        <ul>
          <li>Provide and improve our services.</li>
          <li>Send you updates and newsletters (with your consent).</li>
          <li>Personalise your experience.</li>
        </ul>
      </div>
    </div>

    <div class="accordion-item">
      <button class="accordion-header">4. Sharing Your Data</button>
      <div class="accordion-body">
        <p>We do not sell your personal data. We may share with:</p>
        <ul>
          <li>Service providers (hosting, email).</li>
          <li>Legal authorities if required by law.</li>
        </ul>
      </div>
    </div>

    <div class="accordion-item">
      <button class="accordion-header">5. Your Rights</button>
      <div class="accordion-body">
        <p>You have the right to:</p>
        <ul>
          <li>Access your personal data.</li>
          <li>Request correction or deletion.</li>
          <li>Withdraw consent at any time.</li>
        </ul>
      </div>
    </div>

    <div class="accordion-item">
      <button class="accordion-header">6. Contact Us</button>
      <div class="accordion-body">
        <p>If you have any questions, <a href="contact.php">get in touch</a>.</p>
      </div>
    </div>
  </div>
</main>

<?php include "../includes/footer.php"; ?>
</body>
</html>

<?php include "../includes/navbar.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Cookie Policy | FoodFusion</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="../assets/css/cookie.css">
  <script src="../assets/js/cookies.js" defer></script>
</head>
<body>
  <header class="policy-hero">
    <h1>Cookie Policy</h1>
    <p>How we use cookies on FoodFusion</p>
  </header>

  <main class="policy-container">
    <div class="policy-search">
      <input type="text" id="policy-search" placeholder="Search cookie topics…">
    </div>

    <div class="accordion" id="cookie-accordion">
      <div class="accordion-item">
        <button class="accordion-header">1. What Are Cookies?</button>
        <div class="accordion-body">
          <p>Cookies are small text files stored on your device by your browser. They help us remember your preferences and improve your experience.</p>
        </div>
      </div>
      <div class="accordion-item">
        <button class="accordion-header">2. Types of Cookies We Use</button>
        <div class="accordion-body">
          <ul>
            <li><strong>Essential Cookies:</strong> Required for basic site functions (e.g. session cookies).</li>
            <li><strong>Performance Cookies:</strong> Help us understand usage (e.g. Google Analytics).</li>
            <li><strong>Functional Cookies:</strong> Remember your settings (e.g. language, theme).</li>
            <li><strong>Advertising Cookies:</strong> Deliver relevant ads (third‑party cookies).</li>
          </ul>
        </div>
      </div>
      <div class="accordion-item">
        <button class="accordion-header">3. How to Control Cookies</button>
        <div class="accordion-body">
          <p>You can manage or disable cookies via your browser settings. Note that disabling essential cookies may affect site functionality.</p>
        </div>
      </div>
      <div class="accordion-item">
        <button class="accordion-header">4. Third‑Party Cookies</button>
        <div class="accordion-body">
          <p>We use third‑party services (e.g. analytics, social media widgets) that may set their own cookies. Review their policies for details.</p>
        </div>
      </div>
      <div class="accordion-item">
        <button class="accordion-header">5. Changes to This Policy</button>
        <div class="accordion-body">
          <p>We may update this policy occasionally. The “Last updated” date at the top will reflect any changes.</p>
        </div>
      </div>
    </div>
  </main>

  <?php include "../includes/footer.php"; ?>
</body>
</html>

<?php include("../includes/navbar.php"); ?>

<link rel="stylesheet" href="../assets/css/community.css">
<link rel="stylesheet" href="../assets/css/cookie.css">

<div class="community-hero">
    <div class="overlay">
        <h1>Community Cookbook</h1>
        <p>Share your favourite recipes, cooking tips, and experiences!</p>
    </div>
</div>
  <!-- Cookie Acceptance Banner -->
  <div id="cookie-banner" class="cookie-banner">
    <p>
      We use cookies to give you the best experience. 
      <a href="cookie-policy.php">Learn more</a>
    </p>
    <button id="accept-cookies">Accept</button>
  </div>

  <!-- Cookie script -->
  <script src="../assets/js/cookie.js"></script>

  <!-- Cookie script -->
  <script src="../assets/js/cookie.js"></script>
<!-- Recipe Submission Form -->
<div class="recipe-form">
  <h2>Share Your Recipe</h2>
  <form id="recipeForm">
      <input type="text" id="recipeTitle" placeholder="Recipe Title" required />
      
      <textarea id="recipeDescription" placeholder="Tell us about this dish..." required></textarea>
      
      <input type="text" id="recipeAuthor" placeholder="Your Name" required />
      
      <div id="ingredients">
          <input type="text" name="ingredients[]" placeholder="Ingredient" required />
      </div>
      
      <button type="button" onclick="addIngredient()">+ Add Another Ingredient</button>
      
      <textarea id="instructions" placeholder="Step-by-step instructions" required></textarea>
      
      <button type="submit">Submit Recipe</button>
      
      <p id="statusMessage" style="margin-top: 15px;"></p>
  </form>
</div>


<!-- Community Posts -->
<div class="community-posts">
    <h2>Latest Community Recipes</h2>
    <div id="posts-container">
        <!-- Dynamic posts will appear here -->
    </div>
</div>

<script src="../assets/js/community.js"></script>

<?php include("../includes/footer.php"); ?>

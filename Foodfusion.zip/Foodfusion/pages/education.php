<?php include "../includes/navbar.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Educational Resources | FoodFusion</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="../assets/css/education.css">
  <script src="../assets/js/education.js" defer></script>
</head>
<body>

  <header class="edu-hero">
    <h1>Renewable Energy Resources</h1>
    <p>Download guides, explore infographics, and watch tutorials</p>
  </header>

  <main class="edu-container">

    <!-- Downloadable Guides -->
    <section>
      <h2>📥 Downloadable Guides</h2>
      <div class="card-grid">
        <?php for($i=1; $i<=10; $i++): ?>
          <a href="../assets/docs/guide<?= $i ?>.pdf" download class="edu-card">
            <div class="card-inner">
              <div class="card-front">
                <img src="../assets/images/pdf-icon.png" alt="PDF Guide">
                <h3>Guide <?= $i ?></h3>
              </div>
              <div class="card-back">
                <p>Click to download PDF guide <?= $i ?> on renewable energy.</p>
              </div>
            </div>
          </a>
        <?php endfor; ?>
      </div>
    </section>

    <!-- Infographic Gallery -->
    <section>
      <h2>📊 Infographics</h2>
      <div class="card-grid">
        <?php for($i=1; $i<=10; $i++): ?>
          <div class="edu-card">
            <div class="card-inner">
              <div class="card-front">
                <img src="../assets/images/infographic<?= $i ?>.jpg" alt="Infographic <?= $i ?>">
                <h3>Infographic <?= $i ?></h3>
              </div>
              <div class="card-back">
                <p>Learn about topic <?= $i ?> in our detailed infographic.</p>
              </div>
            </div>
          </div>
        <?php endfor; ?>
      </div>
    </section>

    <!-- Video Tutorials Slideshow -->
    <section>
      <h2>🎥 Video Tutorials</h2>
      <div class="slideshow-container">
        <?php
        $videos = [
          "https://www.youtube.com/watch?v=hw2_hEMgE4o",
          "https://www.youtube.com/watch?v=DILJJwsFl3w",
          "https://www.youtube.com/watch?v=ajeeEr5jG9M"
        ];
        foreach($videos as $idx => $url): ?>
          <div class="slide">
            <iframe src="<?= $url ?>" frameborder="0" allowfullscreen></iframe>
          </div>
        <?php endforeach; ?>

        <button class="prev" onclick="plusSlides(-1)">❮</button>
        <button class="next" onclick="plusSlides(1)">❯</button>
      </div>
      <div class="dots">
        <?php for($i=1; $i<=count($videos); $i++): ?>
          <span class="dot" onclick="currentSlide(<?= $i ?>)"></span>
        <?php endfor; ?>
      </div>
    </section>

  </main>

  <?php include "../includes/footer.php"; ?>
</body>
</html>

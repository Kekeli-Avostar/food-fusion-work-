<?php include("../includes/navbar.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Recipe Collection | FoodFusion</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="../assets/css/recipes.css">
  <script src="../assets/js/recipes.js" defer></script>
</head>
<body>

  <section class="recipe-hero">
    <div class="overlay">
      <h1>Our Delicious Recipes</h1>
      <p>Click on any dish to reveal the ingredients!</p>
    </div>
  </section>

  <main class="recipe-grid">
    <?php
    // Static array of 10 recipes
    $recipes = [
      ["id"=>1, "title"=>"Spicy Jollof Rice",      "img"=>"recipe1.jpg", "ings"=>["Rice","Tomato paste","Onions","Pepper","Salt","Oil"]],
      ["id"=>2, "title"=>"Grilled Chicken",        "img"=>"recipe2.jpg", "ings"=>["Chicken","Herbs","Garlic","Salt","Pepper","Olive oil"]],
      ["id"=>3, "title"=>"Chocolate Lava Cake",    "img"=>"recipe3.jpg", "ings"=>["Chocolate","Butter","Sugar","Eggs","Flour","Vanilla"]],
      ["id"=>4, "title"=>"Vegetable Stir Fry",     "img"=>"recipe4.jpg", "ings"=>["Mixed veggies","Soy sauce","Garlic","Ginger","Oil","Salt"]],
      ["id"=>5, "title"=>"Avocado Toast",          "img"=>"recipe5.jpg", "ings"=>["Bread","Avocado","Lemon","Salt","Pepper","Chili flakes"]],
      ["id"=>6, "title"=>"Pancakes",               "img"=>"recipe6.jpg", "ings"=>["Flour","Milk","Eggs","Sugar","Baking powder","Butter"]],
      ["id"=>7, "title"=>"Caesar Salad",           "img"=>"recipe7.jpg", "ings"=>["Lettuce","Croutons","Parmesan","Caesar dressing"]],
      ["id"=>8, "title"=>"Beef Tacos",             "img"=>"recipe8.jpg", "ings"=>["Taco shells","Ground beef","Lettuce","Cheese","Salsa","Sour cream"]],
      ["id"=>9, "title"=>"Mango Smoothie",         "img"=>"recipe9.jpg", "ings"=>["Mango","Yogurt","Honey","Ice","Milk"]],
      ["id"=>10,"title"=>"Spaghetti Bolognese",    "img"=>"recipe10.jpg","ings"=>["Spaghetti","Minced beef","Tomato sauce","Onion","Garlic","Basil"]],
    ];

    foreach ($recipes as $r): ?>
      <div class="recipe-card" data-id="<?= $r['id'] ?>">
        <img src="../assets/images/<?= $r['img'] ?>" alt="<?= htmlspecialchars($r['title']) ?>">
        <h3><?= htmlspecialchars($r['title']) ?></h3>
        <div class="ingredients" id="ings-<?= $r['id'] ?>">
          <h4>Ingredients:</h4>
          <ul>
            <?php foreach ($r['ings'] as $ing): ?>
              <li><?= htmlspecialchars($ing) ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
    <?php endforeach; ?>
  </main>

  <?php include("../includes/footer.php"); ?>
</body>
</html>

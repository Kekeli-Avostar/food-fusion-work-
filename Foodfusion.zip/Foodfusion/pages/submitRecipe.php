<?php
include("../config/db.php");  // Connect to DB

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $description = $_POST["description"];
    $author = $_POST["author"];
    $instructions = $_POST["instructions"];
    $ingredients = json_encode($_POST["ingredients"]);  // Convert to JSON

    $sql = "INSERT INTO recipes (title, description, author, instructions, ingredients)
            VALUES (?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $title, $description, $author, $instructions, $ingredients);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Recipe submitted successfully!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error submitting recipe."]);
    }

    $stmt->close();
    $conn->close();
}
?>

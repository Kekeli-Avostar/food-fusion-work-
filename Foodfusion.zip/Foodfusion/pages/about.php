<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - FoodFusion</title>
    <link rel="stylesheet" href="../assets/css/about.css">
    <link rel="stylesheet" href="../assets/css/cookie.css">

</head>
  <!-- Cookie Acceptance Banner -->
  <div id="cookie-banner" class="cookie-banner">
    <p>
      We use cookies to give you the best experience. 
      <a href="cookie-policy.php">Learn more</a>
    </p>
    <button id="accept-cookies">Accept</button>
  </div>

  <!-- Cookie script -->
  <script src="../assets/js/cookie.js"></script>


    <!-- Include Navigation Bar -->
    <?php include("../includes/navbar.php"); ?>

    <div class="about-hero">
        <div class="overlay">About Us</div>
    </div>

    <div class="about-content">
        <h2>Who We Are</h2>
        <p>FoodFusion is a platform for food lovers to share, explore, and create delicious recipes.</p>

        <h2>Our Team</h2>
        <div class="team">
            <div class="team-member">
                <img src="../assets/images/chef1.jpg" alt="Chef 1">
                <h3>Chef John Doe</h3>
                <p>Head Chef</p>
            </div>
            <div class="team-member">
                <img src="../assets/images/chef2.jpg" alt="Chef 2">
                <h3>Chef Jane Smith</h3>
                <p>Pastry Specialist</p>
            </div>
        </div>
    </div>

    <!-- Include Footer -->
    <?php include("../includes/footer.php"); ?>

</body>
</html>

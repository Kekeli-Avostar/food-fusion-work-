<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FoodFusion | Home</title>
  <link rel="stylesheet" href="../assets/css/styles.css">
  <script src="../assets/js/script.js" defer></script>
</head>
<body>

  <!-- COOKIE CONSENT POP-UP -->
  <div id="cookie-modal" class="cookie-modal">
    <div class="cookie-modal-content">
      <h2>🍪 We use cookies</h2>
      <p>To give you the best experience, we’d like to use cookies. You can accept or decline.</p>
      <div class="cookie-buttons">
        <button id="accept-cookies">Accept</button>
        <button id="decline-cookies">Decline</button>
      </div>
      <p><a href="pages/cookie-policy.php">Learn more</a></p>
    </div>
  </div>

  <!-- NAVIGATION BAR -->
  <nav>
    <div class="logo">FoodFusion</div>
    <ul>
      <li><a href="home.php">Home</a></li>
      <li><a href="about.php">About</a></li>
      <li><a href="recipes.php">Recipes</a></li>
      <li><a href="community.php">Community</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="education.php">Education</a></li>
      <?php if(!isset($_SESSION["user_id"])): ?>
        <li><a href="../auth/login.php" class="login-btn">Login</a></li>
      <?php else: ?>
        <li><a href="../auth/logout.php" class="login-btn">Logout</a></li>
      <?php endif; ?>
      <li><button onclick="openSignup()">Join Us</button></li>
    </ul>
  </nav>

  <!-- HERO SECTION -->
  <header class="parallax">
    <div class="overlay">
      <h1>Welcome to FoodFusion</h1>
      <p>Discover, Share, and Enjoy Delicious Recipes</p>
    </div>
  </header>

  <!-- FEATURED RECIPES CAROUSEL -->
  <section class="carousel">
    <h2>Featured Recipes</h2>
    <div class="carousel-container">
      <?php
      // Example array; in real code, fetch from DB
      $featured = [
        ["img"=>"recipe1.jpg","title"=>"Spicy Jollof Rice"],
        ["img"=>"recipe2.jpg","title"=>"Grilled Chicken with Herbs"],
        ["img"=>"recipe3.jpg","title"=>"Chocolate Lava Cake"],
      ];
      foreach($featured as $r):
      ?>
      <div class="carousel-slide" onclick="location.href='recipes.php'">
        <div class="slide-inner">
          <img src="../assets/images/<?= $r['img'] ?>" alt="<?= $r['title'] ?>">
          <h3><?= $r['title'] ?></h3>
          <div class="share-icons">
            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode('http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']) ?>" target="_blank">📘</a>
            <a href="https://twitter.com/intent/tweet?url=<?= urlencode('http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']) ?>" target="_blank">🐦</a>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- SIGN-UP POP-UP FORM -->
  <div id="signup-modal" class="modal">
  <div class="modal-content">
    <button class="close" onclick="closeSignup()" aria-label="Close">&times;</button>
    <h2>Join FoodFusion</h2>
    <form id="signup-form" action="../auth/register.php" method="POST" onsubmit="return validateForm()">
      <input type="text" name="first_name" placeholder="First Name" required>
      <input type="text" name="last_name" placeholder="Last Name" required>
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>
      <button type="submit">Sign Up</button>
    </form>
  </div>
</div>


  <!-- FOOTER -->
  <footer>
    <p>&copy; 2025 FoodFusion. All rights reserved.</p>
    <nav class="footer-links">
      <a href="privacy-policy.php">Privacy Policy</a> |
      <a href="cookie-policy.php">Cookie Policy</a>
    </nav>
    <div class="socials">
      <a href="https://www.facebook.com/FoodFusionPK" target="_blank">Facebook</a> |
      <a href="https://www.instagram.com/foodfusionpk/?fbclid=IwY2xjawJqCAFleHRuA2FlbQIxMAABHq87wwierc9b-Lg-X1p_2bxDiot83YpMRiwFELbTlbefgcvQyIL3EloPiLya_aem_N97_cPVUvFsCDqqgpsVtWg#" target="_blank">Instagram</a> |
      <a href="https://twitter.com" target="_blank">Twitter</a>
    </div>
  </footer>

</body>
</html>

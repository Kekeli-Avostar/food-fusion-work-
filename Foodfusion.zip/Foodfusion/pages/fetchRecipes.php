<?php
include("../config/db.php");

$sql = "SELECT * FROM recipes ORDER BY id DESC";
$result = $conn->query($sql);

$recipes = [];

while ($row = $result->fetch_assoc()) {
    $row["ingredients"] = json_decode($row["ingredients"]);  // Convert JSON to array
    $recipes[] = $row;
}

echo json_encode($recipes);

$conn->close();
?>

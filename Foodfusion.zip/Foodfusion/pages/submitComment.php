<?php
include("../config/db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $recipe_id = $_POST["recipe_id"];
    $comment_text = $_POST["comment"];
    $comment_author = $_POST["author"];

    $sql = "INSERT INTO comments (recipe_id, comment_text, comment_author)
            VALUES (?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $recipe_id, $comment_text, $comment_author);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Comment added!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error adding comment."]);
    }

    $stmt->close();
    $conn->close();
}
?>

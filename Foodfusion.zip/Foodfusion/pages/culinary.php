<?php include("../includes/navbar.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Culinary Resources | FoodFusion</title>
  <link rel="stylesheet" href="../assets/css/culinary.css">
</head>
<body><!-- Cookie Acceptance Banner -->
  <div id="cookie-banner" class="cookie-banner">
    <p>
      We use cookies to give you the best experience. 
      <a href="cookie-policy.php">Learn more</a>
    </p>
    <button id="accept-cookies">Accept</button>
  </div>

  <!-- Cookie script -->
  <script src="../assets/js/cookie.js"></script>
  <!-- Hero Section with Parallax Effect -->
  <div class="culinary-hero">
    <div class="overlay">
      <h1>Culinary Resources</h1>
      <p>Your Gateway to Culinary Mastery!</p>
    </div>
  </div>

  <!-- Resources Section -->
  <section class="resources">
    <div class="resource-item">
      <h2>Downloadable Recipe Cards</h2>
      <p>Get high-quality recipe cards in PDF format for your favorite dishes.</p>
      <a href="../assets/downloads/recipe_cards.pdf" download>Download Recipe Cards</a>
    </div>

    <div class="resource-item">
      <h2>Cooking Tutorials</h2>
      <p>Step-by-step tutorials to enhance your cooking skills.</p>
      <a href="../assets/downloads/cooking_tutorials.pdf" download>Download Tutorials</a>
    </div>

    <div class="resource-item">
      <h2>Instructional Videos</h2>
      <p>Watch our curated videos on various cooking techniques and kitchen hacks.</p>
      <div class="video-container">
        <iframe src="https://www.youtube.com/watch?v=BHcyuzXRqLs" 
                title="Cooking Tutorial Video" 
                frameborder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowfullscreen></iframe>
      </div>
    </div>
  </section>

  <?php include("../includes/footer.php"); ?>
</body>
</html>

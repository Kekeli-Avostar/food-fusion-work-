<?php
$error = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require_once "../config/db.php";

    $first_name = trim($_POST["first_name"]);
    $last_name  = trim($_POST["last_name"]);      // NEW
    $email      = trim($_POST["email"]);
    $password   = $_POST["password"];
    $hash       = password_hash($password, PASSWORD_BCRYPT);

    // Basic server-side validation
    if (!$first_name || !$last_name || !$email || !$password) {
        $error = "All fields are required.";
    } else {
        $sql = "INSERT INTO users (first_name, last_name, email, password_hash)
                VALUES (:first_name, :last_name, :email, :hash)";
        $stmt = $conn->prepare($sql);
        if ($stmt->execute([
            ":first_name" => $first_name,
            ":last_name"  => $last_name,
            ":email"      => $email,
            ":hash"       => $hash
        ])) {
            header("Location: login.php");
            exit;
        } else {
            $error = "Registration failed. Try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register | FoodFusion</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link rel="stylesheet" href="../assets/css/auth.css">
  <script src="../assets/js/auth.js" defer></script>
</head>
<body>
  <div class="auth-container">
    <h2>Create Account</h2>
    <?php if ($error): ?>
      <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    <form class="auth-form" method="POST">
      <input type="text" name="first_name" placeholder="First Name" required>
      <input type="text" name="last_name"  placeholder="Last Name" required>  <!-- NEW -->
      <input type="email" name="email"      placeholder="Email"     required>
      <div style="position:relative;">
        <input id="password" type="password" name="password" placeholder="Password" required>
        <span class="toggle-password" data-toggle="password">👁️</span>
      </div>
      <button type="submit">Register</button>
    </form>
    <p>Already have an account? <a href="login.php">Log in here</a></p>
  </div>
</body>
</html>
